/**
 * TriviaService fetches trivia questions from the Open Trivia Database,
 * processes the data, and logs details to MongoDB.
 *
 * It performs the business logic for the trivia quiz flow:
 * - Fetching trivia
 * - Shuffling answer choices
 * - Building question objects
 * - Logging analytics
 *
 * Author: Seon Jhang
 */
package service;

import model.MongoLogger;
import model.TriviaQuestion;
import org.apache.commons.text.StringEscapeUtils;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;
import java.util.*;

public class TriviaService {
    private static final String API_URL = "https://opentdb.com/api.php?amount=10&category=12&difficulty=easy&type=multiple";
    /**
     * Fetches trivia questions from the Open Trivia DB API,
     * formats the questions, and logs metadata to MongoDB.
     *
     * @param clientIp  IP address of the mobile user
     * @param userAgent User-Agent string from the Android device
     * @return List of TriviaQuestion objects for the client
     * @throws Exception if network or parsing fails
     */
    public List<TriviaQuestion> fetchQuestionsAndLog(String clientIp, String userAgent) throws Exception {
        long startTime = System.currentTimeMillis();

        HttpURLConnection conn = (HttpURLConnection) new URL(API_URL).openConnection();
        conn.setRequestMethod("GET");

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder result = new StringBuilder();
        String line;
        while ((line = in.readLine()) != null) result.append(line);
        in.close();

        JSONArray results = new JSONObject(result.toString()).getJSONArray("results");
        List<TriviaQuestion> questions = new ArrayList<>();

        for (int i = 0; i < results.length(); i++) {
            JSONObject trivia = results.getJSONObject(i);
            String question = StringEscapeUtils.unescapeHtml4(trivia.getString("question"));
            String correct = StringEscapeUtils.unescapeHtml4(trivia.getString("correct_answer"));
            JSONArray incorrects = trivia.getJSONArray("incorrect_answers");

            List<String> options = new ArrayList<>();
            options.add(correct);
            for (int j = 0; j < incorrects.length(); j++)
                options.add(StringEscapeUtils.unescapeHtml4(incorrects.getString(j)));

            Collections.shuffle(options);
            int correctIndex = options.indexOf(correct);

            questions.add(new TriviaQuestion(question, options, correctIndex));

            long duration = System.currentTimeMillis() - startTime;
            Document logDoc = new Document()
                    .append("timestamp", Instant.now().toString())
                    .append("question", question)
                    .append("correct_answer", correct)
                    .append("correct_index", correctIndex)
                    .append("category", trivia.optString("category"))
                    .append("difficulty", trivia.optString("difficulty"))
                    .append("type", trivia.optString("type"))
                    .append("client_ip", clientIp)
                    .append("user_agent", userAgent)
                    .append("server_response_time_ms", duration)
                    .append("third_party_api", API_URL);

            MongoLogger.log(logDoc);
        }

        return questions;
    }
}
