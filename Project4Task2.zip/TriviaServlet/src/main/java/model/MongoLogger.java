/**
 * MongoLogger is responsible for inserting and retrieving trivia
 * request logs from a MongoDB Atlas collection.
 *
 * Logs include request data, question metadata, and API performance.
 *
 * Author: Seon Jhang
 */
package model;

import com.mongodb.client.*;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class MongoLogger {
    private static MongoCollection<Document> collection;

    static {
        String uri = "mongodb+srv://seonyjhang:F13OGv35BTxT0459@cluster0.55ycp.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        MongoClient mongoClient = MongoClients.create(uri);
        MongoDatabase database = mongoClient.getDatabase("trivia_logs");
        collection = database.getCollection("trivia_logs");
    }
    /**
     * Inserts a new log document into the MongoDB collection.
     *
     * @param doc A BSON Document containing trivia request metadata
     */
    public static void log(Document doc) {
        collection.insertOne(doc);
    }

    /**
     * Retrieves all log entries stored in the collection.
     *
     * @return List of BSON Documents representing log records
     */
    public static List<Document> getAllLogs() {
        return collection.find().into(new ArrayList<>());
    }
}
