/**
 * Represents a trivia question used in the quiz app.
 * Stores the question text, list of answer options,
 * and the index of the correct answer in the list.
 *
 * Author: Seon Jhang
 */
package model;

import java.util.List;

public class TriviaQuestion {
    private String question;
    private List<String> options;
    private int correctIndex;

    /**
     * Constructs a TriviaQuestion instance.
     *
     * @param question     The trivia question string
     * @param options      A list of answer options (shuffled)
     * @param correctIndex The index of the correct option
     */
    public TriviaQuestion(String question, List<String> options, int correctIndex) {
        this.question = question;
        this.options = options;
        this.correctIndex = correctIndex;
    }

    public String getQuestion() { return question; }
    public List<String> getOptions() { return options; }
    public int getCorrectIndex() { return correctIndex; }
}
