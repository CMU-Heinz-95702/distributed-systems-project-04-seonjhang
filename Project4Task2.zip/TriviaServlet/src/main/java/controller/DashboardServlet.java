/**
 * DashboardServlet handles requests to the /dashboard endpoint.
 * It retrieves all trivia request logs from MongoDB and computes
 * analytics to be displayed on a web-based dashboard via index.jsp.
 *
 * Analytics displayed:
 * - Total number of requests
 * - Average server response time
 * - Top trivia category requested
 *
 * Author: Seon Jhang
 */
package controller;

import com.mongodb.client.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import model.MongoLogger;
import org.bson.Document;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    /**
     * Handles HTTP GET requests for the dashboard page.
     *
     * @param req  HttpServletRequest
     * @param res  HttpServletResponse
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        List<Document> logs = MongoLogger.getAllLogs();

        long totalRequests = logs.size();
        double avgResponseTime = logs.stream()
                .filter(log -> log.containsKey("server_response_time_ms"))
                .mapToLong(log -> log.getLong("server_response_time_ms"))
                .average().orElse(0);

        String topCategory = logs.stream()
                .filter(log -> log.containsKey("category"))
                .collect(Collectors.groupingBy(log -> log.getString("category"), Collectors.counting()))
                .entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey).orElse("N/A");

        req.setAttribute("logs", logs);
        req.setAttribute("totalRequests", totalRequests);
        req.setAttribute("avgResponseTime", avgResponseTime);
        req.setAttribute("topCategory", topCategory);

        req.getRequestDispatcher("/index.jsp").forward(req, res);
    }
}