/**
 * Servlet that handles the /trivia endpoint.
 * Responds to GET requests by returning 10 trivia questions
 * in a custom JSON format for the Android application.
 *
 * The servlet delegates data fetching and logging to TriviaService.
 * If an error occurs, it returns a JSON error message.
 *
 * Author: Seon Jhang
 */
package controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import model.TriviaQuestion;
import org.json.JSONArray;
import org.json.JSONObject;
import service.TriviaService;

import java.io.IOException;
import java.util.List;

@WebServlet("/trivia")
public class TriviaServlet extends HttpServlet {
    private final TriviaService triviaService = new TriviaService();
    /**
     * Handles GET requests to the /trivia endpoint.
     *
     * @param req HttpServletRequest containing client metadata
     * @param res HttpServletResponse used to return JSON data or error
     * @throws ServletException if servlet fails to handle the request
     * @throws IOException      if an input or output error is detected
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        try {
            List<TriviaQuestion> questions = triviaService.fetchQuestionsAndLog(
                    req.getRemoteAddr(),
                    req.getHeader("User-Agent")
            );

            JSONArray jsonArray = new JSONArray();
            for (TriviaQuestion q : questions) {
                JSONObject obj = new JSONObject();
                obj.put("question", q.getQuestion());
                obj.put("options", q.getOptions());
                obj.put("correct_index", q.getCorrectIndex());
                jsonArray.put(obj);
            }

            res.setContentType("application/json");
            res.setCharacterEncoding("UTF-8");
            res.getWriter().print(jsonArray.toString());

        } catch (Exception e) {
            e.printStackTrace();
            JSONObject error = new JSONObject();
            error.put("error", "Internal server error: " + e.getMessage());
            res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            res.getWriter().print(error.toString());
        }
    }
}