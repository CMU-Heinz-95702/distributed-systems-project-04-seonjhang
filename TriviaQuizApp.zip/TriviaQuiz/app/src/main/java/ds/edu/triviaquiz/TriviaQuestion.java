package ds.edu.triviaquiz;

import java.util.List;

public class TriviaQuestion {
    public String question;
    public List<String> options;
    public int correctIndex;

    public TriviaQuestion(String question, List<String> options, int correctIndex) {
        this.question = question;
        this.options = options;
        this.correctIndex = correctIndex;
    }
}