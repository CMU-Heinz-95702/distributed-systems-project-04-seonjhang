package ds.edu.triviaquiz;
import java.util.List;

public interface TriviaCallback {
    void onTriviaReady(List<TriviaQuestion> questions);
    void onTriviaError(String errorMessage);
}

