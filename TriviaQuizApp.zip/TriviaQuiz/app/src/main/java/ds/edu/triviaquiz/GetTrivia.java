package ds.edu.triviaquiz;

import android.app.Activity;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

public class GetTrivia {
    private final Activity activity;
    private final TriviaCallback callback;

    public GetTrivia(Activity activity, TriviaCallback callback) {
        this.activity = activity;
        this.callback = callback;
    }

    public void fetch() {
        new Thread(() -> {
            List<TriviaQuestion> questions = fetchTrivia();
            activity.runOnUiThread(() -> {
                if (questions == null) {
                    callback.onTriviaError("Network error. Please try again.");
                } else {
                    callback.onTriviaReady(questions);
                }
            });
        }).start();
    }

    private List<TriviaQuestion> fetchTrivia() {
        try {
            URL url = new URL("https://upgraded-engine-6659jqvq9j3r7q7-8080.app.github.dev/trivia");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder jsonBuilder = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                jsonBuilder.append(line);
            }
            in.close();

            JSONArray result = new JSONArray(jsonBuilder.toString());
            List<TriviaQuestion> questions = new ArrayList<>();

            for (int i = 0; i < result.length(); i++) {
                JSONObject trivia = result.getJSONObject(i);
                String question = trivia.getString("question");
                JSONArray opts = trivia.getJSONArray("options");
                int correctIndex = trivia.getInt("correct_index");

                List<String> options = new ArrayList<>();
                for (int j = 0; j < opts.length(); j++) {
                    options.add(opts.getString(j));
                }

                questions.add(new TriviaQuestion(question, options, correctIndex));
            }

            return questions;

        } catch (Exception e) {
            Log.e("GetTrivia", "Error fetching trivia", e);
            return null;
        }
    }
}