package ds.edu.triviaquiz;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

import ds.edu.triviaquiz.databinding.FragmentSecondBinding;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;
    private List<TriviaQuestion> cachedQuestions = new ArrayList<>();
    private int currentIndex = 0;
    private int correctCount = 0;
    private int wrongCount = 0;
    private String playerName = "Player";

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSecondBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (getArguments() != null) {
            playerName = getArguments().getString("playerName", "Player");
        }

        loadTrivia();

        binding.answer1.setOnClickListener(v -> checkAnswer(0));
        binding.answer2.setOnClickListener(v -> checkAnswer(1));
        binding.answer3.setOnClickListener(v -> checkAnswer(2));
        binding.answer4.setOnClickListener(v -> checkAnswer(3));
        binding.nextButton.setOnClickListener(v -> showNextQuestion());
    }

    private void loadTrivia() {
        binding.questionText.setText("Loading...");
        new GetTrivia(requireActivity(), new TriviaCallback() {
            @Override
            public void onTriviaReady(List<TriviaQuestion> questions) {
                if (questions == null || questions.isEmpty()) {
                    onTriviaError("No trivia questions available.");
                    return;
                }
                cachedQuestions = questions;
                currentIndex = 0;
                correctCount = 0;
                wrongCount = 0;
                showQuestion();
            }

            @Override
            public void onTriviaError(String errorMessage) {
                Toast.makeText(getContext(), errorMessage, Toast.LENGTH_LONG).show();
                binding.questionText.setText("Error loading trivia.");
            }
        }).fetch();
    }

    private void showQuestion() {
        if (currentIndex >= cachedQuestions.size()) {
            showResult();
            return;
        }

        TriviaQuestion question = cachedQuestions.get(currentIndex);
        binding.questionText.setText("Q" + (currentIndex + 1) + ". " + question.question); // ✅ Here!

        binding.answer1.setText(question.options.get(0));
        binding.answer2.setText(question.options.get(1));
        binding.answer3.setText(question.options.get(2));
        binding.answer4.setText(question.options.get(3));

        binding.answer1.setVisibility(View.VISIBLE);
        binding.answer2.setVisibility(View.VISIBLE);
        binding.answer3.setVisibility(View.VISIBLE);
        binding.answer4.setVisibility(View.VISIBLE);
        binding.nextButton.setVisibility(View.GONE);
    }

    private void checkAnswer(int selectedIndex) {
        TriviaQuestion question = cachedQuestions.get(currentIndex);
        if (selectedIndex == question.correctIndex) {
            correctCount++;
            Toast.makeText(getContext(), "Correct 🎉", Toast.LENGTH_SHORT).show();
        } else {
            wrongCount++;
            Toast.makeText(getContext(), "Wrong 😢", Toast.LENGTH_SHORT).show();
        }
        binding.nextButton.setVisibility(View.VISIBLE);
    }

    private void showNextQuestion() {
        currentIndex++;
        showQuestion();
    }

    private void showResult() {
        binding.questionText.setText("Nice job, " + playerName + "! 🎉\nCorrect: " + correctCount + "\nWrong: " + wrongCount);

        binding.answer1.setVisibility(View.GONE);
        binding.answer2.setVisibility(View.GONE);
        binding.answer3.setVisibility(View.GONE);
        binding.answer4.setVisibility(View.GONE);

        binding.nextButton.setText("Resume Quiz");
        binding.nextButton.setVisibility(View.VISIBLE);
        binding.nextButton.setOnClickListener(v -> loadTrivia());
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}